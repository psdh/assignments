Name : Prabhjyot Singh Sodhi
ID No : 2013A7PS151P

Assigned problem : Q 48

Steps to execute program 
1) compile program using given makefile : 
	Enter the command : make
2) execute program with : /exe
3) Enter input as and when the program asks for it(no commmand line arguments).
4) You can give just one n per program run.


For eg:

make 

./exe

Enter size of stack for which the number of ways is to be evaluated : 
5
The number of ways for a 5 card stack is :   164


Some sample inputs with outputs are :


	Input    : Output
            1           3		
	    2		8		
	    4 	       60
 	    6         448 
            10      24960   

**Warning : Don't enter very large values for n , Since they will lead to a lot of time consumption and may even yield segmentation fault(due to stack overflow) **
